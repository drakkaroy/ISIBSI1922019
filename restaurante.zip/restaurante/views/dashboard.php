<!DOCTYPE html>
<html lang="en">

<?php 
    require_once('../utils/config.php');
    include_once(PATH.'views/global/head.php'); 
?>

<body>
    <?php include_once(PATH.'views/global/nav.php'); ?>
        
    <div class="container p-5">
        <h1 class="text-center">Bienvenido al nuestro restaurante!</h1>
    </div>

    <?php include_once(PATH.'views/global/footer.php'); ?>
</body>

</html>





