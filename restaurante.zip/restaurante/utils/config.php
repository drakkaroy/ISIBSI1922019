<?php

define('PATH', $_SERVER['DOCUMENT_ROOT'].'/ISIBSI1922019/restaurante/');

// Database Data
define('SERVERNAME','localhost');
define('USERNAME','root');
define('PASSWORD','');
define('DBNAME','restaurante');
