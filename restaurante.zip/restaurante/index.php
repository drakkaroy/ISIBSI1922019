<?php
    require_once('utils/config.php');
    header("Location: views/dashboard.php");